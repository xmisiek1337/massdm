package pl.misiek.massdm.client;

public class MassDMClient {
}
