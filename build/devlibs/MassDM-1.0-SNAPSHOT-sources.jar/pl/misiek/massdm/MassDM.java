package pl.misiek.massdm;

public class MassDM {
}
