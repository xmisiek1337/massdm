package pl.misiek.massdm;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class MassDMMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("massdm");
    private static final ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
    private static ScheduledFuture<?> currentTask;
    private static boolean running = false;
    private static KeyBinding guiKeyBinding;

    public static boolean isRunning() {
        return running;
    }

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("massdm")
                    .then(literal("send")
                            .then(argument("message", StringArgumentType.greedyString())
                                    .executes(ctx -> {
                                        String message = StringArgumentType.getString(ctx, "message");
                                        MassDMMod.startMassDM(message, 1.5);
                                        return 1;
                                    })
                            )
                    )
                    .then(literal("send")
                            .then(argument("delay", DoubleArgumentType.doubleArg(0.1, 10.0))
                                    .then(argument("message", StringArgumentType.greedyString())
                                            .executes(ctx -> {
                                                double delay = DoubleArgumentType.getDouble(ctx, "delay");
                                                String message = StringArgumentType.getString(ctx, "message");
                                                MassDMMod.startMassDM(message, delay);
                                                return 1;
                                            })
                                    )
                            )
                    )
                    .then(literal("list")
                            .executes(ctx -> {
                                listPlayers(ctx.getSource());
                                return 1;
                            })
                    )
                    .then(literal("stop")
                            .executes(ctx -> {
                                MassDMMod.stopMassDM();
                                return 1;
                            })
                    )
                    .then(literal("help")
                            .executes(ctx -> {
                                sendHelp(ctx.getSource());
                                return 1;
                            })
                    )
            );
        });

        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Otwórz MassDM GUI", 
                InputUtil.Type.KEYSYM, 
                GLFW.GLFW_KEY_J, 
                "MassDM"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKeyBinding.wasPressed()) {
                if (client.player != null && client.currentScreen == null) {
                    client.setScreen(new MassDMScreen());
                }
            }
        });

        LOGGER.info("[MassDM] Mod załadowany! Użyj /massdm help lub skrótu klawiszowego (domyślnie J)");
    }

    private void listPlayers(FabricClientCommandSource source) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.getNetworkHandler() == null) {
            source.sendFeedback(Text.literal("§d[ᴍᴀssᴅᴍ] §fɴɪᴇ ᴊᴇsᴛᴇś ᴘᴏłąᴄᴢᴏɴʏ ᴢ sᴇʀᴡᴇʀᴇᴍ!"));
            return;
        }

        Collection<PlayerListEntry> entries = client.getNetworkHandler().getPlayerList();
        List<String> players = entries.stream()
                .map(e -> e.getProfile().getName())
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .collect(Collectors.toList());

        source.sendFeedback(Text.literal("§d[ᴍᴀssᴅᴍ] §fᴢɴᴀʟᴇᴢɪᴏɴᴏ §d" + players.size() + " §fɢʀᴀᴄᴢʏ:"));
        StringBuilder sb = new StringBuilder("§f");
        for (int i = 0; i < players.size(); i++) {
            sb.append(players.get(i));
            if (i < players.size() - 1) sb.append("§8, §f");
            if (sb.length() > 80) {
                source.sendFeedback(Text.literal(sb.toString()));
                sb = new StringBuilder("§f");
            }
        }
        if (sb.length() > 2) source.sendFeedback(Text.literal(sb.toString()));
    }

    public static void startMassDM(String message, double delayMs) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (running) {
            if (client.player != null) {
                client.player.sendMessage(
                        Text.literal("§d[ᴍᴀssᴅᴍ] §fᴊᴜż ᴛʀᴡᴀ ᴡʏsʏłᴀɴɪᴇ! ᴜżʏᴊ /massdm stop"), false);
            }
            return;
        }


        if (client.player == null || client.getNetworkHandler() == null) {
            if (client.player != null) {
                client.player.sendMessage(Text.literal("§d[ᴍᴀssᴅᴍ] §fɴɪᴇ ᴊᴇsᴛᴇś ᴘᴏłąᴄᴢᴏɴʏ ᴢ sᴇʀᴡᴇʀᴇᴍ!"), false);
            }
            return;
        }

        Collection<PlayerListEntry> entries = client.getNetworkHandler().getPlayerList();
        List<String> players = entries.stream()
                .map(e -> e.getProfile().getName())
                .filter(name -> !name.equals(client.player.getGameProfile().getName()))
                .collect(Collectors.toList());

        if (players.isEmpty()) {
            client.player.sendMessage(Text.literal("§d[ᴍᴀssᴅᴍ] §fʙʀᴀᴋ ɪɴɴʏᴄʜ ɢʀᴀᴄᴢʏ ɴᴀ sᴇʀᴡᴇʀᴢᴇ!"), false);
            return;
        }

        running = true;
        long delay = (long) (delayMs * 1000);
        client.player.sendMessage(Text.literal(
                String.format("§d[ᴍᴀssᴅᴍ] §fᴡʏsʏłᴀᴍ ᴅᴏ §d%d §fɢʀᴀᴄᴢʏ ᴢ ᴏᴘóźɴɪᴇɴɪᴇᴍ §d%.1fs§f...",
                        players.size(), delayMs)), false);

        final int[] index = {0};
        currentTask = executor.scheduleAtFixedRate(() -> {
            if (!running || index[0] >= players.size()) {
                running = false;
                if (index[0] >= players.size()) {
                    client.execute(() -> {
                        if (client.player != null) {
                            client.player.sendMessage(
                                    Text.literal("§d[ᴍᴀssᴅᴍ] §fᴡʏsłᴀɴᴏ ᴅᴏ ᴡsᴢʏsᴛᴋɪᴄʜ §d" + players.size() + " §fɢʀᴀᴄᴢʏ!"), false);
                        }
                    });
                }
                if (currentTask != null) {
                    currentTask.cancel(false);
                    currentTask = null;
                }
                return;
            }

            String target = players.get(index[0]++);
            String cmd = "/msg " + target + " " + message;
            client.execute(() -> {
                if (client.player != null && client.player.networkHandler != null) {
                    client.player.networkHandler.sendChatCommand(cmd.substring(1));
                    client.player.sendMessage(
                            Text.literal("§d[ᴍᴀssᴅᴍ] §f→ §d" + target + " §f(" + index[0] + "/" + players.size() + ")"), false);
                }
            });

            LOGGER.info("[MassDM] → {}: {}", target, message);
        }, 0, delay, TimeUnit.MILLISECONDS);
    }

    public static void stopMassDM() {
        running = false;
        if (currentTask != null) {
            currentTask.cancel(true);
            currentTask = null;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(Text.literal("§d[ᴍᴀssᴅᴍ] §fᴢᴀᴛʀᴢʏᴍᴀɴᴏ ᴡʏsʏłᴀɴɪᴇ!"), false);
        }
    }

    private void sendHelp(FabricClientCommandSource source) {
        source.sendFeedback(Text.literal("§d=== ᴍᴀssᴅᴍ ʜᴇʟᴘ ==="));
        source.sendFeedback(Text.literal("§d/massdm list §f- ʟɪsᴛᴀ ɢʀᴀᴄᴢʏ"));
        source.sendFeedback(Text.literal("§d/massdm send <msg> §f- ᴡʏśʟɪᴊ ᴅᴏ ᴡsᴢʏsᴛᴋɪᴄʜ"));
        source.sendFeedback(Text.literal("§d/massdm send <delay> <msg> §f- ᴢ ᴏᴘóźɴɪᴇɴɪᴇᴍ"));
        source.sendFeedback(Text.literal("§d/massdm stop §f- ᴢᴀᴛʀᴢʏᴍᴀᴊ"));
        source.sendFeedback(Text.literal("§dSkrót GUI (domyślnie J) §f- ᴏᴛᴡóʀᴢ ɪɴᴛᴇʀꜰᴇᴊs"));
    }
}