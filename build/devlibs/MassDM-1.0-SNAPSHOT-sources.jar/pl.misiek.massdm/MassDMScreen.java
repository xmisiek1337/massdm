package pl.misiek.massdm;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MassDMScreen extends Screen {
    private TextFieldWidget messageField;
    private SliderWidget delaySlider;
    private List<String> players = new ArrayList<>();
    private String status = "§fɢᴏᴛᴏᴡʏ.";
    private double currentDelay = 1.585;

    protected MassDMScreen() {
        super(Text.literal("ᴍᴀssᴅᴍ"));
    }

    @Override
    protected void init() {
        int center = this.width / 2;

        this.messageField = new TextFieldWidget(
                textRenderer, center - 100, 80, 200, 20, Text.literal("ᴡɪᴀᴅᴏᴍᴏść"));
        this.messageField.setMaxLength(256);
        this.messageField.setText("Wiadomość testowa");
        addDrawableChild(this.messageField);

        this.delaySlider = new SliderWidget(center - 100, 115, 200, 20,
                Text.literal("ᴏᴘóźɴɪᴇɴɪᴇ: 1.5 s"), 0.15) {
            @Override
            protected void updateMessage() {
                double val = 0.1 + (this.value * 9.9);
                this.setMessage(Text.literal(String.format("ᴏᴘóźɴɪᴇɴɪᴇ: %.1f s", val)));
            }

            @Override
            protected void applyValue() {
                MassDMScreen.this.currentDelay = 0.1 + (this.value * 9.9);
            }
        };
        addDrawableChild(this.delaySlider);

        addDrawableChild(new PurpleButton(center - 100, 150, 95, 20,
                Text.literal("📨 sᴛᴀʀᴛ"), button -> startMassDM()));

        addDrawableChild(new PurpleButton(center + 5, 150, 95, 20,
                Text.literal("⏹ sᴛᴏᴘ"), button -> stopMassDM()));

        addDrawableChild(new PurpleButton(center - 100, 190, 200, 20,
                Text.literal("✕ ᴢᴀᴍᴋɴɪᴊ"), button -> this.close()));

        refreshPlayerList();
    }

    private void refreshPlayerList() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() == null) {
            status = "§dɴɪᴇ ᴊᴇsᴛᴇś ᴘᴏłąᴄᴢᴏɴʏ ᴢ sᴇʀᴡᴇʀᴇᴍ!";
            return;
        }

        this.players = client.getNetworkHandler().getPlayerList().stream()
                .map(e -> e.getProfile().getName())
                .filter(name -> !name.equals(client.player.getGameProfile().getName()))
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .collect(Collectors.toList());

        status = "§fᴢɴᴀʟᴇᴢɪᴏɴᴏ §d" + players.size() + " §fɢʀᴀᴄᴢʏ ᴏɴʟɪɴᴇ";
        MassDMMod.LOGGER.info("[MassDM] Odświeżono listę: {} graczy", players.size());
    }

    private void startMassDM() {
        String msg = messageField.getText().trim();
        if (msg.isEmpty()) {
            status = "§dᴡᴘɪsᴢ ᴛʀᴇść ᴡɪᴀᴅᴏᴍᴏśᴄɪ!";
            return;
        }
        if (players.isEmpty()) {
            status = "§dʙʀᴀᴋ ɪɴɴʏᴄʜ ɢʀᴀᴄᴢʏ ɴᴀ sᴇʀᴡᴇʀᴢᴇ!";
            return;
        }

        MassDMMod.startMassDM(msg, this.currentDelay);
        status = "§fᴜʀᴜᴄʜᴏᴍɪᴏɴᴏ ᴍᴀsᴏᴡᴇ ᴡʏsʏłᴀɴɪᴇ!";
    }

    private void stopMassDM() {
        MassDMMod.stopMassDM();
        status = "§dᴢᴀᴛʀᴢʏᴍᴀɴᴏ!";
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("§lᴍᴀssᴅᴍ"), width / 2, 30, 0xFFFFFF);
        
        context.drawTextWithShadow(textRenderer, Text.literal("ᴛʀᴇść ᴡɪᴀᴅᴏᴍᴏśᴄɪ:"), width / 2 - 100, 68, 0xAAAAAA);

        super.render(context, mouseX, mouseY, delta);

        if (MassDMMod.isRunning()) {
            status = "§dᴡʏsʏłᴀɴɪᴇ ᴡ ᴛᴏᴋᴜ...";
        } else if (status.equals("§dᴡʏsʏłᴀɴɪᴇ ᴡ ᴛᴏᴋᴜ...")) {
            status = "§fᴢᴀᴋᴏńᴄᴢᴏɴᴏ ᴡʏsʏłᴀɴɪᴇ!";
        }

        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal(status), width / 2, height - 30, 0xFFFFFF);
    }

    private static class PurpleButton extends ButtonWidget {
        public PurpleButton(int x, int y, int width, int height, Text message, PressAction onPress) {
            super(x, y, width, height, message, onPress, DEFAULT_NARRATION_SUPPLIER);
        }

        @Override
        public void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
            int bgColor = this.isHovered() ? 0xFF9933FF : 0xFF6600CC;
            context.fill(this.getX(), this.getY(), this.getX() + this.width, this.getY() + this.height, 0xFFFFFFFF);
            context.fill(this.getX() + 1, this.getY() + 1, this.getX() + this.width - 1, this.getY() + this.height - 1, bgColor);
            
            int textColor = this.active ? 0xFFFFFF : 0xA0A0A0;
            context.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, this.getMessage(), this.getX() + this.width / 2, this.getY() + (this.height - 8) / 2, textColor);
        }
    }
}